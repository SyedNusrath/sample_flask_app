(function($) {
    'use strict'

    $('#dropper1').dateDropper();










})(jQuery);